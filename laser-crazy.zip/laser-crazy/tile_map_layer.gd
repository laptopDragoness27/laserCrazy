extends TileMapLayer

@export var interactiveItems = {
	
}
@export var interactiveNames = {
	
}

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	for x in get_used_cells():
		var cellcoords = get_cell_atlas_coords(x)
		if cellcoords in interactiveItems:
			var newitemscoords = Vector2(x.x*64+32,x.y*64+32)
			erase_cell(x)
			var newitem = interactiveItems[cellcoords].instantiate()
			newitem.add_to_group("locks")
			get_parent().add_child.call_deferred(newitem)
			newitem.global_position=newitemscoords
			newitem.name=str(interactiveNames[cellcoords],x)
