extends CharacterBody2D

#defines constants, use these to change how the player moves!
const DECEL=30
const ACCEL=10
const MAXSPEED = 400

func calculatePolarity(inputnum):
	#returns the polatiry of input num (1 if positive, -1 if negative)
	return inputnum/abs(inputnum)

func makePointOnScreen(point:Vector2):
	if (point.x<0 or point.x>1152) and (point.y>0 or point.y<-648):
		#if the point ins't on screen, halve it until it is!
		makePointOnScreen(point/2)
	else:
		return point

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	#LASER SECTION START
	#sets the point where the laser ends to a point far offscreen in a path that crosses the mouse
	$laserBeam.position=$laserGun/Marker2D.global_position-position
	$laserBeam.target_position=(get_global_mouse_position()-position)*2000
	#if the laser is oolliding with something, make the laser end at where it collides, otherwise end where the laser terminates
	if $laserBeam.is_colliding():
		#clear the points from last frame
		$laserLine.clear_points()
		#make a point where the player is to start the laser
		$laserLine.add_point($laserGun/Marker2D.global_position-position)
		#terminate the laser at the colision point, relative to the player
		$laserLine.add_point($laserBeam.get_collision_point()-position)
	elif len($laserLine.points)>1:
		#first 2 same as last section
		$laserLine.clear_points()
		$laserLine.add_point($laserGun/Marker2D.position)
		#ends where the laser ends, offscreen.
		$laserLine.add_point($laserBeam.target_position)
	#LASER SECTION END
	
	#MOVEMENT HANDLING SECTION START
	#gets input as 2d vector, multiplied by how much acceleration you want
	var direction = Vector2(Input.get_axis("left","right")*ACCEL,Input.get_axis("up","down")*ACCEL)
	
	#handles deceleration if either axis of movement isn't being touched
	if direction.x==0 or calculatePolarity(velocity.x)!=calculatePolarity(direction.x):
		velocity.x=move_toward(velocity.x,0,DECEL)
	if direction.y==0 or calculatePolarity(velocity.y)!=calculatePolarity(direction.y):
		velocity.y=move_toward(velocity.y,0,DECEL)
	#adds direction (doens't do anything if there isn't any user input)
	velocity+=direction
	
	#applies maximum speed
	velocity.x=clamp(velocity.x,-MAXSPEED,MAXSPEED)
	velocity.y=clamp(velocity.y,-MAXSPEED,MAXSPEED)
	
	move_and_slide()
	#INPUT HANDLING SECTION END
